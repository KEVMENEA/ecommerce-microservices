package com.menea.ecommerce.user_service.application;

import com.menea.ecommerce.user_service.api.dto.RegisterUserRequest;
import com.menea.ecommerce.user_service.api.dto.UserResponse;
import com.menea.ecommerce.user_service.domain.Role;
import com.menea.ecommerce.user_service.domain.User;
import com.menea.ecommerce.user_service.domain.UserRepository;
import com.menea.ecommerce.user_service.mapper.UserMapper;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
@RequiredArgsConstructor
public class UserApplicationService {


    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public UserResponse register(RegisterUserRequest request) {

        if (userRepository.existsByEmail(request.email().toLowerCase())) {
            throw new IllegalArgumentException("Email already exists");
        }

        User user = userMapper.toEntity(request);

        user.setPasswordHash(
                passwordEncoder.encode(request.password())
        );

        user.setRoles(Set.of(Role.CUSTOMER));

        User saved = userRepository.save(user);

        return userMapper.toResponse(saved);
    }
}
