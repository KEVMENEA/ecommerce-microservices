package com.menea.ecommerce.user_service.domain;

import com.menea.ecommerce.user_service.api.dto.RegisterUserRequest;
import com.menea.ecommerce.user_service.api.dto.UserResponse;
import com.menea.ecommerce.user_service.application.UserApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1/users/register")
@RequiredArgsConstructor
public class UserController {
    private final UserApplicationService userService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse register(@Valid @RequestBody RegisterUserRequest registerUserRequest) {
        return userService.register(registerUserRequest);
    }

}


